package tanks.gui.screen;

public interface IDarkScreen
{

}
