package tanks.gui.screen;

public interface IConditionalOverlayScreen extends IOverlayScreen
{
    boolean isOverlayEnabled();
}
