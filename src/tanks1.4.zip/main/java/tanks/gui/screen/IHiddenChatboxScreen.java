package tanks.gui.screen;

public interface IHiddenChatboxScreen
{
    //screens implementing this will have a hidden chat box
}
