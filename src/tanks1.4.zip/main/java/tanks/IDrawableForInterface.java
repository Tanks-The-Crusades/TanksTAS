package tanks;

public interface IDrawableForInterface extends IDrawable
{
	void drawAt(double x, double y);
	
	void drawForInterface(double x, double y);
}
