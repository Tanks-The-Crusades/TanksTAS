package tanks.event;

public interface IEvent 
{

}
