package tanks;

import tanks.IDrawable;

public interface IDrawableWithGlow extends IDrawable
{
    void drawGlow();

    boolean isGlowEnabled();
}
