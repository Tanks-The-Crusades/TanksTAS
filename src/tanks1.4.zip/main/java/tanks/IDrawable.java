package tanks;

public interface IDrawable 
{
	void draw();
}
