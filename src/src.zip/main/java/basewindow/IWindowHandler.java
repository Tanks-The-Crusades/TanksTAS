package basewindow;

public interface IWindowHandler 
{
	boolean attemptCloseWindow();

	void onWindowClose();
}
