package tanks;

public interface IGameObject {}