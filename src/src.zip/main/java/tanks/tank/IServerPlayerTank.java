package tanks.tank;

import tanks.Player;

public interface IServerPlayerTank
{
    Player getPlayer();
}
