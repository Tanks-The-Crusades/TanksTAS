package tanks.tank;

public interface IAvoidObject
{
    double getRadius();

    double getSeverity(double posX, double posY);
}
