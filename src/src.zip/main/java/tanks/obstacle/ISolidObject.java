package tanks.obstacle;

public interface ISolidObject
{
	Face[] getHorizontalFaces();

	Face[] getVerticalFaces();
}
