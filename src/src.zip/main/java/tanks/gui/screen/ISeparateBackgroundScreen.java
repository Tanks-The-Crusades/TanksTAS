package tanks.gui.screen;

public interface ISeparateBackgroundScreen
{
    void drawWithoutBackground();
}
