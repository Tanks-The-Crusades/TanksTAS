package tanks.gui.screen;

public interface IOnlineScreen
{

}
