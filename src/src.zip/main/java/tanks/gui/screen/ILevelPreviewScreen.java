package tanks.gui.screen;

import tanks.tank.TankSpawnMarker;

import java.util.ArrayList;

public interface ILevelPreviewScreen
{
    ArrayList<TankSpawnMarker> getSpawns();
}
