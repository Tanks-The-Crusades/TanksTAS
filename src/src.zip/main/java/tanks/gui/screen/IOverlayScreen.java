package tanks.gui.screen;

public interface IOverlayScreen
{
}
