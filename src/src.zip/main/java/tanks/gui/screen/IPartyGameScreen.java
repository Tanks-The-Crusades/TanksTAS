package tanks.gui.screen;

public interface IPartyGameScreen
{
    // if a screen class implements this, players will not be able to join a party while this is being displayed
}
