package tanks.gui;

import tanks.IDrawable;

public interface IFixedMenu extends IDrawable
{
    void draw();

    void update();
}
